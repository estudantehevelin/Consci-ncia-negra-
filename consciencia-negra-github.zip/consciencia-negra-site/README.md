# Consciência Negra — História, Cultura e Transformação

Site educativo responsivo em HTML, CSS e JavaScript puro. Não precisa de frameworks nem de processo de build.

## Como visualizar
Abra `index.html` no navegador.

## Como publicar no GitHub Pages
1. Crie um repositório no GitHub (por exemplo, `consciencia-negra`).
2. Envie o arquivo `index.html` para a raiz do repositório.
3. Acesse **Settings → Pages**.
4. Em **Build and deployment**, escolha **Deploy from a branch**.
5. Selecione a branch `main` e a pasta `/ (root)`, depois salve.
6. Aguarde a publicação e abra o endereço indicado pelo GitHub Pages.

## Funcionalidades
- Layout responsivo e navegação fixa com menu móvel.
- Rolagem suave, cards e linha do tempo.
- Busca e filtro de personalidades.
- Filtros de materiais por categoria e faixa etária.
- Modo de alto contraste e controles de tamanho de fonte.
- Compartilhamento nativo ou cópia do link.
- Mural demonstrativo com validação básica no navegador.
- Preferência por navegação por teclado, landmarks, rótulos e mensagens acessíveis.

## Antes de publicar
- Substitua `contato@exemplo.org` e adicione redes sociais reais.
- Confira e complemente as informações históricas com fontes confiáveis.
- A imagem da capa é carregada de um endereço externo do Unsplash. Confirme licença/crédito e, se preferir, hospede uma imagem autorizada no próprio repositório.
- O mural é apenas uma demonstração local. Para receber mensagens publicamente, conecte um backend, política de privacidade, proteção contra spam e moderação humana/automática. Não use apenas a lista de termos bloqueados como moderação.
- Revise acessibilidade, textos, links, classificação indicativa e créditos antes de uso institucional.

## Estrutura
- `index.html` — site completo (estrutura, estilos e interações).
